create function avg_sal() returns numeric
    language plpgsql
as
$$
declare
	result numeric(8,2);
begin
	select sum(salary) into result
		from instructor
		where instructor.dept_name = dept_name;
	return result;
end;
$$;

alter function avg_sal() owner to ryan;

