create view tot_credits(year, sum) as
SELECT takes.year,
       sum(course.credits) AS sum
FROM student
         JOIN takes USING (id)
         JOIN course USING (course_id)
GROUP BY takes.year;

alter table tot_credits
    owner to ryan;

