create function avg_sal(dept_name character varying) returns numeric
    language plpgsql
as
$$
declare result numeric(8,2);
begin 
	select avg(salary) into result
	from instructor
	where instructor.dept_name = $1;
	
	return result;
end;
$$;

alter function avg_sal(varchar) owner to ryan;

